<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'Allen');
define('DB_PASS', 'allen@123');
define('DB_NAME', 'inventory_management_system');


//Create Connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

//Check Connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
